import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import AnimatedHero from "@/components/AnimatedHero";
import ClassGrid from "@/components/ClassGrid";
import Footer from "@/components/Footer";
import { classData } from "@/utils/classData";
import { Button } from "@/components/ui/button";
import { Monitor, MapPin, Sparkles, BookOpen, Users, Award } from "lucide-react";
import { motion } from "framer-motion";

const Index = () => {
  // Featured classes for the homepage (first 3)
  const featuredClasses = classData.slice(0, 3);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <AnimatedHero />
        
        {/* Featured Classes Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <motion.div 
              className="mb-12 text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Classes</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Discover our most popular tech courses chosen by students and industry experts.
              </p>
            </motion.div>
            
            <ClassGrid classes={featuredClasses} />
            
            <motion.div 
              className="mt-12 text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Button asChild className="gradient-bg">
                <Link to="/classes">View All Classes</Link>
              </Button>
            </motion.div>
          </div>
        </section>
        
        {/* Learning Options Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <motion.div 
              className="mb-12 text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Choose Your Learning Path</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                We offer flexible learning options to fit your lifestyle and preferences.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Virtual Classes */}
              <motion.div 
                className="bg-white p-8 rounded-xl shadow-md border border-gray-100 transition-all duration-300 hover:shadow-lg"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                whileHover={{ y: -5 }}
              >
                <div className="mb-6 w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                  <Monitor className="h-8 w-8 text-tech-blue" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Virtual Classes</h3>
                <p className="text-gray-600 mb-6">
                  Learn from the comfort of your home with our interactive online classes. Access expert instructors, real-time collaboration, and a flexible schedule.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start">
                    <span className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2 mt-0.5">
                      <span className="h-2.5 w-2.5 rounded-full bg-green-500"></span>
                    </span>
                    <span className="text-gray-700">Live interactive sessions</span>
                  </li>
                  <li className="flex items-start">
                    <span className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2 mt-0.5">
                      <span className="h-2.5 w-2.5 rounded-full bg-green-500"></span>
                    </span>
                    <span className="text-gray-700">Access to recorded lessons</span>
                  </li>
                  <li className="flex items-start">
                    <span className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2 mt-0.5">
                      <span className="h-2.5 w-2.5 rounded-full bg-green-500"></span>
                    </span>
                    <span className="text-gray-700">Flexible scheduling options</span>
                  </li>
                </ul>
                <Button asChild variant="outline" className="w-full border-tech-blue text-tech-blue hover:text-white hover-gradient-bg">
                  <Link to="/classes">View Virtual Classes</Link>
                </Button>
              </motion.div>
              
              {/* Physical Classes */}
              <motion.div 
                className="bg-white p-8 rounded-xl shadow-md border border-gray-100 transition-all duration-300 hover:shadow-lg"
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                whileHover={{ y: -5 }}
              >
                <div className="mb-6 w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center">
                  <MapPin className="h-8 w-8 text-tech-purple" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Physical Classes</h3>
                <p className="text-gray-600 mb-6">
                  Join us in person at our state-of-the-art tech campuses. Experience hands-on learning with dedicated lab time and direct mentor support.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start">
                    <span className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2 mt-0.5">
                      <span className="h-2.5 w-2.5 rounded-full bg-green-500"></span>
                    </span>
                    <span className="text-gray-700">Hands-on lab sessions</span>
                  </li>
                  <li className="flex items-start">
                    <span className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2 mt-0.5">
                      <span className="h-2.5 w-2.5 rounded-full bg-green-500"></span>
                    </span>
                    <span className="text-gray-700">Networking opportunities</span>
                  </li>
                  <li className="flex items-start">
                    <span className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2 mt-0.5">
                      <span className="h-2.5 w-2.5 rounded-full bg-green-500"></span>
                    </span>
                    <span className="text-gray-700">Campus resources access</span>
                  </li>
                </ul>
                <Button asChild variant="outline" className="w-full border-tech-purple text-tech-purple hover:text-white hover:bg-tech-purple">
                  <Link to="/classes">View Physical Classes</Link>
                </Button>
              </motion.div>
            </div>
          </div>
        </section>
        
        {/* Why Choose Us Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <motion.div 
              className="mb-12 text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Eden's Tech Hub</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                We're committed to providing the highest quality tech education with industry-leading instructors.
              </p>
            </motion.div>
            
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
              variants={container}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
            >
              <motion.div 
                className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center text-center"
                variants={item}
                whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
              >
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Sparkles className="h-6 w-6 text-tech-blue" />
                </div>
                <h3 className="text-lg font-bold mb-2">Cutting-Edge Curriculum</h3>
                <p className="text-gray-600">
                  Our courses are regularly updated to reflect the latest industry trends and technologies.
                </p>
              </motion.div>
              
              <motion.div 
                className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center text-center"
                variants={item}
                whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
              >
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-tech-purple" />
                </div>
                <h3 className="text-lg font-bold mb-2">Expert Instructors</h3>
                <p className="text-gray-600">
                  Learn from seasoned professionals with years of real-world industry experience.
                </p>
              </motion.div>
              
              <motion.div 
                className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center text-center"
                variants={item}
                whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
              >
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <BookOpen className="h-6 w-6 text-tech-blue" />
                </div>
                <h3 className="text-lg font-bold mb-2">Flexible Learning</h3>
                <p className="text-gray-600">
                  Choose between virtual and physical classes to fit your schedule and learning style.
                </p>
              </motion.div>
              
              <motion.div 
                className="bg-white p-6 rounded-xl shadow-sm flex flex-col items-center text-center"
                variants={item}
                whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
              >
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                  <Award className="h-6 w-6 text-tech-purple" />
                </div>
                <h3 className="text-lg font-bold mb-2">Industry Recognition</h3>
                <p className="text-gray-600">
                  Our certifications are recognized by top tech companies and organizations.
                </p>
              </motion.div>
            </motion.div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <motion.div 
              className="bg-gradient-to-r from-tech-blue to-tech-purple rounded-2xl p-8 md:p-12 text-white text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              whileHover={{ scale: 1.02 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Advance Your Tech Career?</h2>
              <p className="text-xl mb-8 max-w-3xl mx-auto opacity-90">
                Join thousands of successful students who have transformed their careers with Eden's Tech Hub.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button asChild size="lg" className="bg-white text-tech-blue hover:bg-gray-100">
                  <Link to="/classes">Explore Classes</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
                  <Link to="/register">Register Now</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
