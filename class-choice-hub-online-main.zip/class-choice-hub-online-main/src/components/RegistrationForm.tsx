
import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { getClassById, classData } from "@/utils/classData";
import { TechClass } from "@/types";

const RegistrationForm = () => {
  const [searchParams] = useSearchParams();
  const classId = searchParams.get("classId");
  const navigate = useNavigate();
  
  const [selectedClass, setSelectedClass] = useState<TechClass | null>(null);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    agreedToTerms: false,
  });
  
  useEffect(() => {
    if (classId) {
      const foundClass = getClassById(classId);
      if (foundClass) {
        setSelectedClass(foundClass);
      }
    }
  }, [classId]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCheckboxChange = (checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      agreedToTerms: checked,
    }));
  };

  const handleClassSelect = (value: string) => {
    const selectedClass = getClassById(value);
    setSelectedClass(selectedClass || null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedClass) {
      toast.error("Please select a class to register for");
      return;
    }
    
    if (!formData.agreedToTerms) {
      toast.error("You must agree to the terms and conditions");
      return;
    }
    
    if (!formData.firstName || !formData.lastName || !formData.email) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    // In a real app, you would submit this data to your backend
    console.log("Registration submitted:", { ...formData, classId: selectedClass.id });
    
    // Simulate successful registration
    toast.success("Registration successful! Proceeding to payment...");
    
    // Redirect to payment page
    setTimeout(() => {
      navigate(`/payment?classId=${selectedClass.id}`);
    }, 1500);
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6 md:p-8 border border-gray-100">
      <h2 className="text-2xl font-bold mb-6">Registration Form</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-4">
          <div>
            <Label htmlFor="class-select">Select a Class</Label>
            <Select 
              value={selectedClass?.id || ""} 
              onValueChange={handleClassSelect}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a class" />
              </SelectTrigger>
              <SelectContent>
                {classData.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id}>
                    {cls.title} ({cls.type}) - ${cls.price}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {selectedClass && (
            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium">{selectedClass.title}</h3>
              <div className="text-sm text-gray-600 mt-1">{selectedClass.description}</div>
              <div className="flex justify-between mt-2">
                <span className="text-sm">{selectedClass.type === 'virtual' ? 'Virtual' : 'Physical'}</span>
                <span className="font-medium">${selectedClass.price}</span>
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName">First Name *</Label>
              <Input
                id="firstName"
                name="firstName"
                value={formData.firstName}
                onChange={handleInputChange}
                required
              />
            </div>
            <div>
              <Label htmlFor="lastName">Last Name *</Label>
              <Input
                id="lastName"
                name="lastName"
                value={formData.lastName}
                onChange={handleInputChange}
                required
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleInputChange}
              required
            />
          </div>
          
          <div>
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={handleInputChange}
            />
          </div>
          
          <div>
            <Label htmlFor="address">Address</Label>
            <Input
              id="address"
              name="address"
              value={formData.address}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="terms" 
              checked={formData.agreedToTerms}
              onCheckedChange={handleCheckboxChange}
            />
            <label
              htmlFor="terms"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              I agree to the terms and conditions
            </label>
          </div>
        </div>
        
        <Button type="submit" className="w-full gradient-bg">
          Register Now
        </Button>
      </form>
    </div>
  );
};

export default RegistrationForm;
