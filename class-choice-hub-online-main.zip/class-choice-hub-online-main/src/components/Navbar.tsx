import { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="py-4 border-b border-gray-100 bg-white/80 backdrop-blur-md fixed top-0 left-0 right-0 z-50">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link to="/" className="flex items-center">
          <span className="text-2xl font-bold gradient-text">Eden's Tech Hub</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <Link to="/" className="font-medium text-gray-700 hover:text-tech-blue transition-colors">
            Home
          </Link>
          <Link to="/classes" className="font-medium text-gray-700 hover:text-tech-blue transition-colors">
            Classes
          </Link>
          <Link to="/register" className="font-medium text-gray-700 hover:text-tech-blue transition-colors">
            Register
          </Link>
          <Button asChild className="gradient-bg">
            <Link to="/register">Get Started</Link>
          </Button>
        </div>

        {/* Mobile Navigation Toggle */}
        <div className="md:hidden">
          <button onClick={toggleMenu} aria-label="Toggle menu">
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg z-40 animate-fade-in">
          <div className="flex flex-col space-y-4 p-4">
            <Link 
              to="/" 
              className="font-medium text-gray-700 hover:text-tech-blue transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link 
              to="/classes" 
              className="font-medium text-gray-700 hover:text-tech-blue transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Classes
            </Link>
            <Link 
              to="/register" 
              className="font-medium text-gray-700 hover:text-tech-blue transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Register
            </Link>
            <Button asChild className="gradient-bg w-full">
              <Link to="/register" onClick={() => setIsMenuOpen(false)}>Get Started</Link>
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
