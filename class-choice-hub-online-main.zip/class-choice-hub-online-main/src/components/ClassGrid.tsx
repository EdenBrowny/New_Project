
import { useState } from "react";
import { TechClass } from "@/types";
import ClassCard from "./ClassCard";
import { Button } from "@/components/ui/button";
import { Monitor, MapPin } from "lucide-react";

interface ClassGridProps {
  classes: TechClass[];
}

const ClassGrid = ({ classes }: ClassGridProps) => {
  const [filter, setFilter] = useState<'all' | 'virtual' | 'physical'>('all');
  
  const filteredClasses = filter === 'all' 
    ? classes 
    : classes.filter(cls => cls.type === filter);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap gap-2 justify-center sm:justify-start">
        <Button
          variant={filter === 'all' ? 'default' : 'outline'}
          onClick={() => setFilter('all')}
          className={filter === 'all' ? 'gradient-bg' : ''}
        >
          All Classes
        </Button>
        <Button
          variant={filter === 'virtual' ? 'default' : 'outline'}
          onClick={() => setFilter('virtual')}
          className={filter === 'virtual' ? 'bg-tech-blue text-white hover:bg-tech-blue/90' : ''}
        >
          <Monitor className="mr-2 h-4 w-4" />
          Virtual
        </Button>
        <Button
          variant={filter === 'physical' ? 'default' : 'outline'}
          onClick={() => setFilter('physical')}
          className={filter === 'physical' ? 'bg-tech-purple text-white hover:bg-tech-purple/90' : ''}
        >
          <MapPin className="mr-2 h-4 w-4" />
          Physical
        </Button>
      </div>
      
      {filteredClasses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredClasses.map((cls) => (
            <ClassCard key={cls.id} techClass={cls} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <h3 className="text-xl font-medium text-gray-600">No classes found for the selected filter.</h3>
          <Button
            onClick={() => setFilter('all')}
            variant="link"
            className="text-tech-blue mt-2"
          >
            View all classes
          </Button>
        </div>
      )}
    </div>
  );
};

export default ClassGrid;
