
import { useState, useEffect } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { getClassById } from "@/utils/classData";
import { TechClass } from "@/types";
import { CreditCard, CheckCircle2 } from "lucide-react";

const Payment = () => {
  const [searchParams] = useSearchParams();
  const classId = searchParams.get("classId");
  const navigate = useNavigate();
  
  const [selectedClass, setSelectedClass] = useState<TechClass | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<"credit-card" | "paypal">("credit-card");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  
  const [formData, setFormData] = useState({
    cardNumber: "",
    cardName: "",
    expiryDate: "",
    cvv: "",
  });
  
  useEffect(() => {
    if (classId) {
      const foundClass = getClassById(classId);
      if (foundClass) {
        setSelectedClass(foundClass);
      } else {
        // Redirect to registration page if class not found
        navigate("/register");
      }
    } else {
      // Redirect to registration page if no class ID provided
      navigate("/register");
    }
  }, [classId, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedClass) {
      toast.error("No class selected for payment");
      navigate("/register");
      return;
    }
    
    if (paymentMethod === "credit-card" && 
        (!formData.cardNumber || !formData.cardName || !formData.expiryDate || !formData.cvv)) {
      toast.error("Please fill in all payment details");
      return;
    }
    
    // In a real app, you would process payment through a payment gateway
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setIsComplete(true);
      toast.success("Payment successful! You're now enrolled.");
    }, 2000);
  };

  if (isComplete) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-grow pt-24">
          <section className="py-16">
            <div className="container mx-auto px-4">
              <div className="max-w-3xl mx-auto text-center">
                <div className="mb-8 flex justify-center">
                  <div className="w-24 h-24 rounded-full bg-green-100 flex items-center justify-center">
                    <CheckCircle2 className="h-12 w-12 text-green-600" />
                  </div>
                </div>
                <h1 className="text-4xl font-bold mb-4">Payment Successful!</h1>
                <p className="text-xl text-gray-600 mb-8">
                  Thank you for enrolling in {selectedClass?.title}. We've sent a confirmation email with all the details.
                </p>
                <div className="bg-white rounded-xl shadow-md p-6 md:p-8 border border-gray-100 mb-8">
                  <h2 className="text-2xl font-bold mb-4">Class Details</h2>
                  <div className="text-left">
                    <p className="mb-2"><span className="font-medium">Class:</span> {selectedClass?.title}</p>
                    <p className="mb-2"><span className="font-medium">Type:</span> {selectedClass?.type === 'virtual' ? 'Virtual' : 'Physical'}</p>
                    <p className="mb-2"><span className="font-medium">Instructor:</span> {selectedClass?.instructor}</p>
                    <p className="mb-2"><span className="font-medium">Duration:</span> {selectedClass?.duration}</p>
                    <p className="mb-2"><span className="font-medium">Schedule:</span> {selectedClass?.dateTime}</p>
                    {selectedClass?.type === 'physical' && selectedClass.locations && (
                      <p><span className="font-medium">Location:</span> {selectedClass.locations.join(', ')}</p>
                    )}
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button asChild className="gradient-bg">
                    <Link to="/">Return to Home</Link>
                  </Button>
                  <Button asChild variant="outline">
                    <Link to="/classes">Browse More Classes</Link>
                  </Button>
                </div>
              </div>
            </div>
          </section>
        </main>
        
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24">
        {/* Header Section */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Complete Your Payment</h1>
              <p className="text-xl text-gray-600">
                Secure payment for your selected class.
              </p>
            </div>
          </div>
        </section>
        
        {/* Payment Form Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
                {/* Payment Form */}
                <div className="md:col-span-3">
                  <div className="bg-white rounded-xl shadow-md p-6 md:p-8 border border-gray-100">
                    <h2 className="text-2xl font-bold mb-6">Payment Method</h2>
                    
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <RadioGroup 
                        value={paymentMethod} 
                        onValueChange={(value) => setPaymentMethod(value as "credit-card" | "paypal")}
                        className="grid grid-cols-2 gap-4 mb-6"
                      >
                        <div className={`border rounded-lg p-4 flex items-center space-x-2 ${
                          paymentMethod === "credit-card" ? "border-tech-blue bg-blue-50" : "border-gray-200"
                        }`}>
                          <RadioGroupItem value="credit-card" id="credit-card" />
                          <Label htmlFor="credit-card" className="flex-1 cursor-pointer">
                            <div className="flex items-center">
                              <CreditCard className="mr-2 h-5 w-5" />
                              Credit Card
                            </div>
                          </Label>
                        </div>
                        <div className={`border rounded-lg p-4 flex items-center space-x-2 ${
                          paymentMethod === "paypal" ? "border-tech-blue bg-blue-50" : "border-gray-200"
                        }`}>
                          <RadioGroupItem value="paypal" id="paypal" />
                          <Label htmlFor="paypal" className="flex-1 cursor-pointer">
                            <div className="flex items-center">
                              <span className="font-bold text-blue-600 mr-1">Pay</span>
                              <span className="font-bold text-blue-800">Pal</span>
                            </div>
                          </Label>
                        </div>
                      </RadioGroup>
                      
                      {paymentMethod === "credit-card" && (
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="cardNumber">Card Number</Label>
                            <Input
                              id="cardNumber"
                              name="cardNumber"
                              placeholder="1234 5678 9012 3456"
                              value={formData.cardNumber}
                              onChange={handleInputChange}
                              required
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="cardName">Cardholder Name</Label>
                            <Input
                              id="cardName"
                              name="cardName"
                              placeholder="John Doe"
                              value={formData.cardName}
                              onChange={handleInputChange}
                              required
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="expiryDate">Expiry Date</Label>
                              <Input
                                id="expiryDate"
                                name="expiryDate"
                                placeholder="MM/YY"
                                value={formData.expiryDate}
                                onChange={handleInputChange}
                                required
                              />
                            </div>
                            <div>
                              <Label htmlFor="cvv">CVV</Label>
                              <Input
                                id="cvv"
                                name="cvv"
                                placeholder="123"
                                value={formData.cvv}
                                onChange={handleInputChange}
                                required
                              />
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {paymentMethod === "paypal" && (
                        <div className="bg-gray-50 p-6 rounded-lg text-center">
                          <p className="mb-4">You will be redirected to PayPal to complete your payment.</p>
                        </div>
                      )}
                      
                      <Button 
                        type="submit" 
                        className="w-full gradient-bg" 
                        disabled={isProcessing}
                      >
                        {isProcessing ? "Processing..." : `Pay $${selectedClass?.price || 0}`}
                      </Button>
                    </form>
                  </div>
                </div>
                
                {/* Order Summary */}
                <div className="md:col-span-2">
                  <div className="bg-white rounded-xl shadow-md p-6 md:p-8 border border-gray-100 sticky top-24">
                    <h2 className="text-xl font-bold mb-4">Order Summary</h2>
                    
                    {selectedClass && (
                      <div>
                        <div className="border-b border-gray-100 pb-4 mb-4">
                          <h3 className="font-medium">{selectedClass.title}</h3>
                          <p className="text-sm text-gray-600">{selectedClass.type === 'virtual' ? 'Virtual' : 'Physical'} Class</p>
                          <p className="text-sm text-gray-600">{selectedClass.duration}</p>
                        </div>
                        
                        <div className="space-y-2 mb-6">
                          <div className="flex justify-between">
                            <span>Class Price</span>
                            <span>${selectedClass.price}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Tax</span>
                            <span>${Math.round(selectedClass.price * 0.08)}</span>
                          </div>
                        </div>
                        
                        <div className="border-t border-gray-100 pt-4">
                          <div className="flex justify-between font-bold">
                            <span>Total</span>
                            <span>${selectedClass.price + Math.round(selectedClass.price * 0.08)}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Payment;
