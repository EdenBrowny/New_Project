
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ClassGrid from "@/components/ClassGrid";
import { classData } from "@/utils/classData";

const Classes = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24">
        {/* Header Section */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Browse Our Classes</h1>
              <p className="text-xl text-gray-600">
                Discover our comprehensive range of tech courses available in both virtual and physical formats.
              </p>
            </div>
          </div>
        </section>
        
        {/* Classes Grid Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <ClassGrid classes={classData} />
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Classes;
