
import { Link } from "react-router-dom";
import { TechClass } from "@/types";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Monitor, MapPin, Clock, User } from "lucide-react";

interface ClassCardProps {
  techClass: TechClass;
}

const ClassCard = ({ techClass }: ClassCardProps) => {
  const {
    id,
    title,
    description,
    type,
    instructor,
    duration,
    price,
    image,
    locations,
    dateTime
  } = techClass;

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 transition-all duration-300 hover:shadow-lg">
      <div className="relative">
        <img
          src={image}
          alt={title}
          className="w-full h-48 object-cover"
        />
        <Badge 
          className={`absolute top-4 right-4 ${
            type === 'virtual' 
              ? 'bg-blue-100 text-tech-blue hover:bg-blue-100' 
              : 'bg-purple-100 text-tech-purple hover:bg-purple-100'
          }`}
        >
          {type === 'virtual' ? (
            <Monitor className="mr-1 h-3 w-3" />
          ) : (
            <MapPin className="mr-1 h-3 w-3" />
          )}
          {type === 'virtual' ? 'Virtual' : 'Physical'}
        </Badge>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{description}</p>
        
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="flex items-center text-sm text-gray-500">
            <User className="h-4 w-4 mr-1 text-gray-400" />
            {instructor}
          </div>
          <div className="flex items-center text-sm text-gray-500">
            <Clock className="h-4 w-4 mr-1 text-gray-400" />
            {duration}
          </div>
        </div>
        
        {type === 'physical' && locations && (
          <div className="mb-4">
            <div className="flex items-start">
              <MapPin className="h-4 w-4 mr-1 text-gray-400 mt-0.5" />
              <div className="text-sm text-gray-500">
                {locations.join(', ')}
              </div>
            </div>
          </div>
        )}
        
        {dateTime && (
          <div className="mb-4">
            <div className="flex items-start">
              <Clock className="h-4 w-4 mr-1 text-gray-400 mt-0.5" />
              <div className="text-sm text-gray-500">{dateTime}</div>
            </div>
          </div>
        )}
        
        <div className="flex items-center justify-between mt-4">
          <span className="text-xl font-bold">${price}</span>
          <Button asChild className="gradient-bg">
            <Link to={`/register?classId=${id}`}>Register</Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ClassCard;
