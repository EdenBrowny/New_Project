
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Monitor, MapPin } from "lucide-react";
import { motion } from "framer-motion";

const AnimatedHero = () => {
  return (
    <section className="pt-24 pb-16 md:pt-32 md:pb-24">
      <div className="container px-4 mx-auto">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 md:pr-8 mb-10 md:mb-0">
            <motion.h1 
              className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              Advance Your Tech Career With <span className="gradient-text">Expert-Led</span> Classes
            </motion.h1>
            <motion.p 
              className="text-lg md:text-xl text-gray-600 mb-8"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              Choose between online and in-person classes taught by industry professionals. Start your tech journey today.
            </motion.p>
            <motion.div 
              className="flex flex-col sm:flex-row gap-4"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
            >
              <Button asChild className="gradient-bg text-white px-8 py-6 text-lg">
                <Link to="/classes">
                  Explore Classes <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" className="border-tech-blue text-tech-blue hover:text-white hover-gradient-bg px-8 py-6 text-lg">
                <Link to="/register">
                  Sign Up Now
                </Link>
              </Button>
            </motion.div>
            <motion.div 
              className="flex flex-col sm:flex-row gap-6 mt-10"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
            >
              <div className="flex items-center">
                <Monitor className="text-tech-blue h-6 w-6 mr-2" />
                <span className="text-gray-700">Virtual Classes</span>
              </div>
              <div className="flex items-center">
                <MapPin className="text-tech-purple h-6 w-6 mr-2" />
                <span className="text-gray-700">Physical Locations</span>
              </div>
            </motion.div>
          </div>
          <motion.div 
            className="md:w-1/2 md:pl-8"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.4 }}
          >
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
              <div className="gradient-bg h-8 w-full"></div>
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-4">Choose Your Learning Style</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <motion.div 
                    className="bg-gray-50 p-4 rounded-lg border border-gray-100 flex flex-col items-center text-center"
                    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                    transition={{ duration: 0.2 }}
                  >
                    <Monitor className="text-tech-blue h-10 w-10 mb-2" />
                    <h4 className="font-medium mb-1">Virtual Classes</h4>
                    <p className="text-sm text-gray-500">Learn from anywhere with live online sessions</p>
                  </motion.div>
                  <motion.div 
                    className="bg-gray-50 p-4 rounded-lg border border-gray-100 flex flex-col items-center text-center"
                    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                    transition={{ duration: 0.2 }}
                  >
                    <MapPin className="text-tech-purple h-10 w-10 mb-2" />
                    <h4 className="font-medium mb-1">Physical Classes</h4>
                    <p className="text-sm text-gray-500">In-person learning at our tech campuses</p>
                  </motion.div>
                </div>
                <motion.div whileHover={{ scale: 1.03 }} transition={{ duration: 0.2 }}>
                  <Button asChild className="w-full gradient-bg">
                    <Link to="/classes">Browse All Classes</Link>
                  </Button>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AnimatedHero;
