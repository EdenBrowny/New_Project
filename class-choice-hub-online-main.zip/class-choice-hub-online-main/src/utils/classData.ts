
import { TechClass } from "@/types";

export const classData: TechClass[] = [
  {
    id: "1",
    title: "Web Development Fundamentals",
    description: "Learn the basics of HTML, CSS, and JavaScript to build responsive websites from scratch.",
    type: "virtual",
    instructor: "Alex Johnson",
    duration: "8 weeks",
    price: 499,
    image: "/placeholder.svg",
    dateTime: "Mondays & Wednesdays, 6-8PM",
    available: true
  },
  {
    id: "2",
    title: "Advanced React Development",
    description: "Master React hooks, context API, and build complex applications with modern practices.",
    type: "virtual",
    instructor: "Sarah Williams",
    duration: "10 weeks",
    price: 699,
    image: "/placeholder.svg",
    dateTime: "Tuesdays & Thursdays, 7-9PM",
    available: true
  },
  {
    id: "3",
    title: "Data Science Bootcamp",
    description: "Dive into data analysis with Python, pandas, and machine learning fundamentals.",
    type: "physical",
    instructor: "Michael Chen",
    duration: "12 weeks",
    price: 1299,
    image: "/placeholder.svg",
    locations: ["New York", "San Francisco"],
    dateTime: "Weekends, 9AM-4PM",
    available: true
  },
  {
    id: "4",
    title: "UX/UI Design Workshop",
    description: "Learn essential design principles and tools for creating beautiful, user-friendly interfaces.",
    type: "physical",
    instructor: "Emma Rodriguez",
    duration: "6 weeks",
    price: 899,
    image: "/placeholder.svg",
    locations: ["Chicago", "Austin"],
    dateTime: "Fridays, 1-5PM",
    available: true
  },
  {
    id: "5",
    title: "Cybersecurity Essentials",
    description: "Learn to protect systems and networks from digital attacks with industry-standard techniques.",
    type: "virtual",
    instructor: "David Smith",
    duration: "8 weeks",
    price: 599,
    image: "/placeholder.svg",
    dateTime: "Tuesdays & Thursdays, 6-8PM",
    available: true
  },
  {
    id: "6",
    title: "Mobile App Development",
    description: "Build native mobile applications for iOS and Android using React Native.",
    type: "physical",
    instructor: "Jason Park",
    duration: "10 weeks",
    price: 999,
    image: "/placeholder.svg",
    locations: ["Seattle", "Boston"],
    dateTime: "Mondays & Wednesdays, 6-9PM",
    available: true
  }
];

export const getClassById = (id: string): TechClass | undefined => {
  return classData.find(cls => cls.id === id);
};

export const getClassesByType = (type: 'virtual' | 'physical' | 'all'): TechClass[] => {
  if (type === 'all') return classData;
  return classData.filter(cls => cls.type === type);
};
