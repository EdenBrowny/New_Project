
export type ClassType = 'virtual' | 'physical';

export interface TechClass {
  id: string;
  title: string;
  description: string;
  type: ClassType;
  instructor: string;
  duration: string;
  price: number;
  image: string;
  locations?: string[];
  dateTime?: string;
  available: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  classIds: string[];
}
